#include <iostream>
#include <cstdlib>
#include <string>
#include <conio.h>

using namespace std;

int main() {
    char q = 'q';

    cout << "Press 'q' to quit or any other key to start System Revitalizer: ";

    char input = _getch();

    if (input == q) {
        cout << "Exiting..." << endl;
        return 0;
    }

    cout << "Running chkdsk.exe..." << endl;
    system("C:\\Windows\\system32\\cmd.exe /c chkdsk.exe");
    cout << "chkdsk.exe completed." << endl;

    cout << "Running sfc /scannow..." << endl;
    system("C:\\Windows\\system32\\cmd.exe /c sfc /scannow");
    cout << "sfc /scannow completed." << endl;

    cout << "Restoring image health..." << endl;
    system("C:\\Windows\\system32\\cmd.exe /c dism /online /cleanup-image /restorehealth");
    cout << "Restoring image health completed." << endl;

    cout << "Clearing the TEMP folder..." << endl;
    system("C:\\Windows\\system32\\cmd.exe /c del /q/f/s %TEMP%\\*");
    cout << "Clearing the TEMP folder completed." << endl;

    cout << "Running disk cleanup..." << endl;
    system("C:\\Windows\\system32\\cleanmgr.exe");
    cout << "Disk cleanup completed." << endl;

    cout << "Process completed. Press enter to exit." << endl;
    cin.get(); // Wait for enter key before exiting

    return 0;
}
